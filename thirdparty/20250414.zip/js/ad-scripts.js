document.querySelectorAll('.ad-complaint-record button').forEach(button => {
    if (button.textContent.trim() === "Completed") {
        button.classList.add('completed');
    }
});

document.querySelectorAll('.ad-rooms-list button').forEach(button => {
    if (button.textContent.trim() === "Remove") {
        button.classList.add('remove');
    }
});
