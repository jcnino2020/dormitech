<?php
session_start();

// Redirect logged-in users to the dashboard
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit;
}

// Database connection
$db = new mysqli('localhost', 'jcnino_admin', 'Group5BSIT2B', 'jcnino_db');

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

$error = '';
$success = '';

// Handle registration form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $db->real_escape_string($_POST['username']);
    $password = $_POST['password'];

    // Validate input
    if (empty($username) || empty($password)) {
        $error = 'Username and password are required.';
    } else {
        // Check if the username already exists
        $check_sql = "SELECT id FROM Users WHERE username = ?";
        $check_stmt = $db->prepare($check_sql);
        if (!$check_stmt) {
            die("Prepare failed: " . $db->error);
        }
        $check_stmt->bind_param("s", $username);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();

        if ($check_result->num_rows > 0) {
            $error = 'Username already exists.';
        } else {
            // Insert new user into the database (no password hashing)
            $insert_sql = "INSERT INTO users (username, password) VALUES (?, ?)";
            $insert_stmt = $db->prepare($insert_sql);
            if (!$insert_stmt) {
                die("Prepare failed: " . $db->error);
            }
            $insert_stmt->bind_param("ss", $username, $password); // Plain text password

            if ($insert_stmt->execute()) {
                $success = 'Account created successfully!';
            } else {
                $error = 'Error creating account. Please try again.';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dormitech - Register</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="icon" href="img/favicon.png" type="image/x-icon">
</head>
<body>
    <div class="login-page">
        <div class="login-container">
            <img src="../img/logob.png" alt="DORMITECH Logo">
            <h2>Create Account</h2>

            <?php if ($error): ?>
                <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="success-message"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>

            <p>Enter your details to create an account</p>

            <!-- Registration form -->
            <form method="POST" action="">
                <input type="text" id="username" name="username" placeholder="Username" required>
                <br><br>
                <input type="password" id="password" name="password" placeholder="Password" required>
                <br><br>
                <button type="submit">Register</button>
                <br><br>
                <p>Already have an account? <a href="login.php">Login here</a></p>
                <p>Need help? Visit our <a href="#">help center</a></p>
            </form>
        </div>
    </div>

    <script src="/js/scripts.js"></script>
</body>
</html>