<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payments - DormiTech</title>
    <link rel="stylesheet" href="../../css/styles.css">
    <link rel="icon" href="../../img/favicon.png" type="image/x-icon">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        #paymentChart {
            height: 300px !important;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">
            <a href="../dashboard.php">
                <img src="../img/logo.png" alt="DORMITECH Logo">
            </a>
        </div>
        <nav>
            <ul>
                <li><a href="../dashboard.php">Home</a></li>
                <li><a href="payments.php" class="selected">Payments</a></li>
                <li><a href="complaints.php">Complaints</a></li>
                <li><a href="chat.php">Chat</a></li>
                <li><a href="notif.php">Notifications</a></li>
                <li><a href="profile.php">Profile</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <h1>Payments and Details</h1>
		<div class="rent-details">
			<div class="detail-item"><b>Current Month:</b> <?= htmlspecialchars($current_month ?? '') ?></div>
			<div class="detail-item"><b>Rent Amount:</b> ₱<?= number_format($rent_amount ?? 0, 2) ?></div>
			<div class="detail-item"><b>Due Date:</b> <?= htmlspecialchars($due_date ?? '') ?></div>
			<div class="detail-item"><b>Status:</b> <?= htmlspecialchars($status ?? '') ?></div>
		</div>

        <section class="payment-methods">
            <h3>Payment Methods</h3>
            <div class="buttons-container">
                <button class="payment-btn gcash">GCash</button>
                <button class="payment-btn maya">Maya</button>
                <button class="payment-btn card">Debit/Credit Card</button>
            </div>
        </section>

        <section class="payment-history">
            <h3>Payment History</h3>
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Amount</th>
                        <th>Method</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($payment_history)): ?>
                        <?php foreach ($payment_history as $payment): ?>
                            <tr>
                                <td><?= htmlspecialchars($payment['PaymentDate']) ?></td>
                                <td>₱<?= number_format($payment['Amount'], 2) ?></td>
                                <td><?= htmlspecialchars($payment['PaymentMethod']) ?></td>
                                <td><?= htmlspecialchars($payment['Status']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4">No payment history found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </section>

        <!-- Add Payment Chart -->
        <section class="payment-chart">
            <h3>Monthly Payment Totals</h3>
            <canvas id="paymentChart"></canvas>
        </section>
    </main>

    <script>
        // Prepare chart data
        const months = [<?php echo '"' . implode('","', array_column($chart_data, 'Month')) . '"'; ?>];
        const amounts = [<?php echo implode(',', array_column($chart_data, 'TotalAmount')); ?>];

        // Initialize Chart.js
        const ctx = document.getElementById('paymentChart').getContext('2d');
        const paymentChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: months,
                datasets: [{
                    label: 'Total Payments (₱)',
                    data: amounts,
                    backgroundColor: 'rgba(75, 192, 192, 0.6)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '₱' + value.toFixed(2);
                            }
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.dataset.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                label += '₱' + context.parsed.y.toFixed(2);
                                return label;
                            }
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>