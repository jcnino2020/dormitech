<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dormitech Login</title>
    <link rel="stylesheet" href="../../css/styles.css">
    <link rel="icon" href="../../img/favicon.png" type="image/x-icon">
</head>
<body>
    <div class="login-page">
        <div class="login-container">
            <img src="../../img/logob.png" alt="DORMITECH Logo">
            <h2>Login</h2>

            <?php if ($error): ?>
                <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <p>Enter your username and password to login</p>

            <form method="POST" action="">
                <input type="hidden" name="next" value="<?php echo htmlspecialchars($next_url); ?>">

                <input type="text" id="username" name="username" placeholder="Username" required>
                <br><br>
                <input type="password" id="password" name="password" placeholder="Password" required>
                <br><br>
                <div class="forgot-links">
                    <a href="#">Forgot Username?</a>
                    <a href="#">Forgot Password?</a>
                </div>
                <br>
                <button type="submit">Login</button>
                <br><br>
                <p>Don't have an account? <a href="register.php">Register</a></p>
                <p>Need help? Visit our <a href="#">help center</a></p>
            </form>
        </div>
    </div>

    <script src="/js/scripts.js"></script>
</body>
</html>