<?php
require_once '../models/UserModel.php';

session_start();

// Redirect logged-in users to the dashboard
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

// Initialize the database connection
$db = new mysqli('localhost', 'jcnino_admin', 'Group5BSIT2B', 'jcnino_db');

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

// Initialize the model
$userModel = new UserModel($db);

// Handle form submission
$error = ''; // Initialize the error variable
$next_url = isset($_SESSION['next_url']) ? $_SESSION['next_url'] : '/';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $db->real_escape_string($_POST['username']);
    $password = $_POST['password'];

    $user = $userModel->authenticateUser($username, $password);

    if ($user) {
        $_SESSION['user_id'] = $user['id'];
        header("Location: " . htmlspecialchars($_POST['next']));
        exit;
    } else {
        $error = 'Invalid username or password'; // Set error message
    }
}

// Pass data to the view
include '../views/login.php';
?>