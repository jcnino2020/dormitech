<?php
session_start();
require_once '../auth.php'; // Database connection
require_once '../model/PaymentModel.php';

// Redirect if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    $_SESSION['next_url'] = $_SERVER['REQUEST_URI'];
    header("Location: ../../../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

$model = new PaymentModel($conn);

// Fetch payment history
$payment_history = $model->getPaymentHistory($user_id);

// Fetch monthly payment totals
$chart_data = $model->getMonthlyPaymentTotals($user_id);

// Prepare current month's rent details
$current_month = date('F Y'); // e.g., "February 2025"
$rent_amount = 2500.00; // Static rent amount
$due_date = date('F d, Y', strtotime('last day of this month')); // Last day of the current month
$status = 'Pending'; // Default status

// Pass data to the view
include '../view/payments.php';