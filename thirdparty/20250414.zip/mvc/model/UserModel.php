<?php
class UserModel {
    private $db;

    public function __construct($dbConnection) {
        $this->db = $dbConnection;
    }

    // Authenticate user by username and password
    public function authenticateUser($username, $password) {
        $sql = "SELECT id, password FROM Users WHERE username = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($user = $result->fetch_assoc()) {
            if ($password === $user['password']) {
                return $user; // Return user data if authentication succeeds
            }
        }
        return false; // Return false if authentication fails
    }
}
?>