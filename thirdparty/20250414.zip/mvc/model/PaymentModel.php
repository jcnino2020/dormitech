<?php
class PaymentModel {
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    public function getPaymentHistory($user_id) {
        $sql = "SELECT PaymentDate, Amount, PaymentMethod, Status FROM Payments WHERE User_ID = ? ORDER BY PaymentDate DESC";
        $stmt = $this->conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        }
        return [];
    }

    public function getMonthlyPaymentTotals($user_id) {
        $sql = "
            SELECT 
                DATE_FORMAT(PaymentDate, '%Y-%m') AS Month, 
                SUM(Amount) AS TotalAmount 
            FROM Payments 
            WHERE User_ID = ? 
            GROUP BY DATE_FORMAT(PaymentDate, '%Y-%m') 
            ORDER BY Month ASC
        ";
        $stmt = $this->conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        }
        return [];
    }
}