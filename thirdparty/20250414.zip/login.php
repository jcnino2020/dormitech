<?php
session_start();

// Redirect if user is already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: user/dashboard.php");
    exit;
}

// Determine the next URL after login
$next_url = isset($_SESSION['next_url']) ? $_SESSION['next_url'] : '/';

// Connect to the database
$db = new mysqli('localhost', 'jcnino_admin', 'Group5BSIT2B', 'jcnino_db');

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

$error = '';

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $db->real_escape_string($_POST['username']);
    $password = $_POST['password'];

    // Query the database for the user
    $sql = "SELECT User_ID, password FROM Users WHERE username = ?";
    $stmt = $db->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($user = $result->fetch_assoc()) {
        // Compare plain-text passwords
        if ($password === $user['password']) {
            $_SESSION['user_id'] = $user['User_ID'];
            header("Location: " . htmlspecialchars($_POST['next']));
            exit;
        } else {
            $error = 'Invalid username or password';
        }
    } else {
        $error = 'Invalid username or password';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dormitech Dashboard</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="icon" href="img/favicon.png" type="image/x-icon">
</head>
<body>
    <div class="login-page">
        <div class="login-container">
            <img src="../img/logob.png" alt="DORMITECH Logo">
            <h2>Login</h2>

            <?php if ($error): ?>
                <div class="error-message"><?php echo $error; ?></div>
            <?php endif; ?>

            <p>Enter your username and password to login</p>

            <form method="POST" action="">
                <input type="hidden" name="next" value="<?php echo htmlspecialchars($next_url); ?>">

                <input type="text" id="username" name="username" placeholder="Username" required>
                <br><br>
                <input type="password" id="password" name="password" placeholder="Password" required>
                <br><br>
                <div class="forgot-links">
                    <a href="#">Forgot Username?</a>
                    <a href="#">Forgot Password?</a>
                </div>
                <br>
                <button type="submit">Login</button>
                <br><br>
                <p>Don't have an account? <a href="register.php">Register</a></p>
                <p>Need help? Visit our <a href="#">help center</a></p>
            </form>
        </div>
    </div>

    <script src="/js/scripts.js"></script>
</body>
</html>